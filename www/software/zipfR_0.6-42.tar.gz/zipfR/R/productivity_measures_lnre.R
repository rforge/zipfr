productivity.measures.lnre <- function (obj, measures, conf.level=.95, ...)
{
  stop("not implemented yet")
}


