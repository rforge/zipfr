EV <- function (obj, N=NA, ...)  UseMethod("EV")

EVm <- function (obj, m, N=NA, ...)  UseMethod("EVm")
