productivity.measures.tfl <- function (obj, measures, ...) {
  productivity.measures(tfl2spc(obj), measures, ...)
}
