# postdlnre <- function (model, x, m, N, ...)  UseMethod("postdlnre")
# postldlnre <- function (model, x, m, N, base=10, log.x=FALSE, ...)  UseMethod("postldlnre")
# postplnre <- function (model, q, m, N, lower.tail=FALSE, ...)  UseMethod("postplnre")
# postqlnre <- function (model, p, m, N, lower.tail=TRUE, ...)  UseMethod("postqlnre")
